<div class="container-fluid">
    <h3 class="mb-4">Selamat datang <?= $user->nama ?></h3>
</div>